import java.text.NumberFormat;
public class PayRollTest {

	public static void main(String[] args)
	{
		NumberFormat nf = NumberFormat.getCurrencyInstance();
		System.out.println("The next employee's ID will be " + Employee.getNextID());
		WorkGroup workgroup = new WorkGroup();
		Payable[] pay = new Payable[5];
		
		
		Invoice invoice = new Invoice("Nuts",20,4.50);
		Invoice inv2 = new Invoice("Bolts",20,4.50);
		annualSalary e1 = new annualSalary("01/05/2020 ");
		workgroup.setGroupName("Team Red");
		workgroup.setSupervisor(e1);
		workgroup.addEmployee(e1);
		e1.setfirstName("Ruben");
		e1.setlastName("Dias");
		e1.gethireDate();
		e1.getBenifits();
		e1.setAnnualSalary(90000);
		pay[0] = e1; // employee added to pay array
		
		System.out.println("First employee's ID is " + e1.getID());
		System.out.println("The next employee's ID will be " +
		
		Employee.getNextID());
		
		HourlyEmployee e2 = new HourlyEmployee("05/14/2022 ");
		e2.setfirstName("Phil");
		e2.setlastName("Foden");
		
		e2.setHoursWorked(50);
		e2.setPayRate(24.50);
		workgroup.addEmployee(e2);
		pay[1] = e2;//added employee 2 to pay array
		
		System.out.println("Second employee's ID is " + e2.getID());
		System.out.println("The next employee's ID will be " +
		
		Employee.getNextID());
		
		CommissionEmployee e3 = new CommissionEmployee("06/16/2010 ");
		e3.setfirstName("David");
		e3.setlastName("Silva");
		e3.setSalesAmt(100);
		e3.setCommissionPct(5.76);
		workgroup.addEmployee(e3);
		System.out.println("Third employee's ID is " + e3.getID());
		System.out.println("The next employee's ID will be " +
		Employee.getNextID() + "\n");
		pay[2] = e3; // added employee 3 to pay array 
		pay[3]= invoice;
		pay[4] = inv2; // added both invoices 
		
		// test toString
		for(Payable s: pay )
		{
		System.out.println(s.toString());
		}
		
		for(Payable t : pay)
			System.out.println(nf.format(t.calcPay()));
		
		int total = 0;
		for(Payable p : pay)
		
			total+=p.calcPay();
			System.out.println("Total payout:" + nf.format(total));
	
	}
}
