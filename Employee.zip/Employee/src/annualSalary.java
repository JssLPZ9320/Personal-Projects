
public class annualSalary extends Employee
{

	private double annualSalary;

	public annualSalary(String hD) 
	{
		super(hD);
		// TODO Auto-generated constructor stub
	}

	public double getAnnualSalary() 
	{
		return annualSalary;
	}

	public void setAnnualSalary(double annualSalary) 
	{
		this.annualSalary = annualSalary;
	}

	@Override
	public String toString()
	{
		return super.toString() + " Annual Salary: " + annualSalary;
	}

	@Override
	public double calcPay()
	{
		return annualSalary / 26;
		
	}

}
