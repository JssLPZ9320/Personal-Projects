
public class CommissionEmployee extends Employee
{
	private double salesAmt;
	private double commissionPct;
	
	public CommissionEmployee(String hD) 
	{
		super(hD);
		// TODO Auto-generated constructor stub
	}

	public double getSalesAmt() {
		return salesAmt;
	}

	public void setSalesAmt(double salesAmt) 
	{
		this.salesAmt = salesAmt;
	}

	public double getCommissionPct() 
	{
		return commissionPct;
	}

	public void setCommissionPct(double commissionPct) 
	{
		this.commissionPct = commissionPct;
	}
@Override
public String toString()
{
	return super.toString() + " sales amount: " + salesAmt + " commission percentage: " + commissionPct;
}

@Override
public double calcPay()
{
	return commissionPct * salesAmt;
}
	
	
}
