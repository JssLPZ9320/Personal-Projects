
public abstract class Employee implements Payable
{
	 private static int nextID = 1;
	 private String firstName;
	 private String lastName;
	 private int employeeID;
	 private String hireDate;
	 private Benifits benifits;
	 
	 public Employee(String hD )
	 {
	 employeeID = nextID;
	 nextID++;
	 hireDate = hD;
	 benifits = new Benifits(50000,"Custom Medicade",5);
	 }
	 public Benifits getBenifits()
	 {
		 return benifits;
	 }
	 public void setBenifits(Benifits benifits)
	 {
		 this.benifits = benifits;
	 }
	 public String getfirstName()
	 {
	 return firstName;
	 }
	 public void setfirstName(String fName)
	 {
	 if(fName.length() > 0)
	 firstName = fName;
	 }
	 public String getlastName()
	 {
	 return lastName;
	 }
	 public void setlastName(String lName)
	 {
	 if(lName.length() > 0 )
	 lastName = lName;
	 }
	 public int getID()
	 {
	 return employeeID;
	 }
	 public static int getNextID()
	 {
	 return nextID;
	 }
	 public String gethireDate()
	 {
	 return hireDate;
	 }
	 public String toString()
	 {
	 String output = lastName + ", " + firstName;
	 output += " (" +getID() + ") Hired " + hireDate + benifits;
	 return output;
	 }
	 
 }


