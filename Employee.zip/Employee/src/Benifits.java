import java.text.NumberFormat;

public class Benifits 
{
	private double insuranceCoverage;
	private String companyName;
	private int numDependents;
	
	public Benifits(double iC, String cN, int nD)
	{
		NumberFormat nf = NumberFormat.getCurrencyInstance();
		nf.format(insuranceCoverage);
		insuranceCoverage = iC;
		companyName = cN;
		numDependents = nD;
	}

	public double getInsuranceCoverage() {
		return insuranceCoverage;
	}

	public void setInsuranceCoverage(double insuranceCoverage) {
		this.insuranceCoverage = insuranceCoverage;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public int getNumDependents() {
		return numDependents;
	}

	public void setNumDependents(int numDependents) {
		this.numDependents = numDependents;
	}

	@Override
	public String toString() 
	{
		return "Benifits [insurance coverage= " + insuranceCoverage + "] for " + numDependents + " dependents" ;
				
	}
	

}
