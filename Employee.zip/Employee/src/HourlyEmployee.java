
public class HourlyEmployee extends Employee
{
	private double hoursWorked;
	private double payRate;
	
	public HourlyEmployee(String hD)
	{
		super(hD);
		// TODO Auto-generated constructor stub
	}

	public double getHoursWorked() 
	{
		return hoursWorked;
	}

	public void setHoursWorked(double hoursWorked) 
	{
		this.hoursWorked = hoursWorked;
	}

	public double getPayRate() {
		return payRate;
	}

	public void setPayRate(double payRate) 
	{
		this.payRate = payRate;
	}
	@Override
	public String toString()
	{
		
		return super.toString() + " Hours worked: " + hoursWorked + " pay rate: " + payRate;
	}

	@Override
	public double calcPay() 
	{
		return hoursWorked * payRate;
	}


}
