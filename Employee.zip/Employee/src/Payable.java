
public interface Payable
{
  public double calcPay();
}
