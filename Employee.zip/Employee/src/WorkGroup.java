import java.util.ArrayList;

	public class WorkGroup
	{
		private String groupName; // a name for this WorkGroup
		private ArrayList<Employee> employees; // a list of Employee objects
		private Employee supervisor;           // an Employee object
		
		public WorkGroup()
		{
			employees = new ArrayList<Employee>();
		}
		
		public void setGroupName(String name) // Sets the name of the WorkGroup
		{
			groupName = name;
		}
		
		public String getGroupName() // Returns the name of the WorkGroup
		{
			return groupName;
		}

		public void addEmployee(Employee newGuy) // Adds an employee to the WorkGroup
		{
			employees.add(newGuy);
			// TODO: add newGuy to employees list
		}
		
		public void setSupervisor(Employee boss) // Designates an Employee as the WorkGroup supervisor
		{
			supervisor = boss;
		}
		
		public Employee getSupervisor() // Returns the Employee who is the supervisor or null
		{
			return supervisor;
		}
		
		public Employee getEmployee(int id) // Retrieves an Employee from the WorkGroup by ID or null
		{
			
			for(int i =1; id < employees.size(); i++)
			{	
				if(employees.get(i).getID() == id)	
				
					return employees.get(i);
			}
			return null;
			
			
		}   
		

		public int count() // Returns the number of employees in the WorkGroup
		{
			// TODO:  Return the length or size of the employees list
			return employees.size();
		}
		
		public void remove(int id) // Removes an Employee from the WorkGroup
		{
			employees.remove(id);
		}
		
		public Employee[] toArray() // Returns an array of Employee objects containing all the employees in this WorkGroup
		{
			Employee[] arr = new Employee[employees.size()];
			for(int i =0; i <arr.length; i++)
			
			arr[i]=(Employee)employees.get(i);
			
			return arr; 
			
		}
		
		public String toString() // Returns a String for neatly displaying all Employees in the WorkGroup
		{
			String output = groupName + " \n supervisor " +  supervisor + "\n";		
			
			for(int i =0; i <employees.size(); i++)
			{
				output += 
				employees.get(i).toString();
				output += " \n";
			}
				
		return "Work Group" + output;
		

				
			
			
		}
	}


