
public class Invoice implements Payable
{
 

private String ProductName;
  private int quantity;
  private double pricePerItem;

  public Invoice (String name, int qty, double item)
  {
	  ProductName = name;
	  quantity = qty;
	  pricePerItem = item;
	  
  }
  public String getProductName() 
  {
  	return ProductName;
  }

  public void setProductName(String productName) 
  {
  	ProductName = productName;
  }

  public int getQuantity() 
  {
  	return quantity;
  }

  public void setQuantity(int quantity) 
  {
  	this.quantity = quantity;
  }

  public double getPricePerItem()
  {
  	return pricePerItem;
  }

  public void setPricePerItem(double pricePerItem) 
  {
  	this.pricePerItem = pricePerItem;
  }

  
public double calcPay() 
{

	  return quantity * pricePerItem;
}
@Override
public String toString() 
{
	return "Invoice [ProductName=" + ProductName + ", quantity=" + quantity + ", pricePerItem=" + pricePerItem
			+ "] Total: " + calcPay();
}


}
