import java.lang.Math;

public class Dice {
	private int die1;
	private int die2;
	
   
	public Dice()
	{
		
	}

	public int getDie1() 
	{
		die1 += 1 + (int) (Math.random() * 6);

		return die1;
	}

	public int getDie2()
	{
		die2 += 1 + (int)(Math.random() * 6);
		return die2;
	}

	
}
