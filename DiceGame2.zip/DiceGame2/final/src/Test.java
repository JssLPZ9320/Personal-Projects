import java.util.Scanner;

public class Test 
{
	

	public static void main(String[] args)
	{
		Game game = new Game();
		 game.player1.setpName1("Player 1 ");
	       game.player2.setpName1("Player 2 ");
	       
		Scanner scanner = new Scanner(System.in);
		String instruction = "This is a simple dice game. Up to two players. Game is played like this: a pair dice will be rolled at random and be added together, the player with the highest total of the dice will win the game. ";
	 
		
		System.out.print(instruction);
	System.out.println("\nWill you like to play? (Y/N)");
	
       char input = 'y';
       input = scanner.next().charAt(0);
       
       while(input == 'Y' || input == 'y')
       {
    	   game.play();
    	    System.out.println("Would you like to play again? (N to quit");
    	    
    	    input = scanner.next().charAt(0);
       }
	
     scanner.close();
	 game.save();
	 game.Inputfile("DiceGame.txt");
	}

	
}