import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;



public class Game 
{
Player player1 = new Player();
Player player2 = new Player();
private Dice dice;

public Game()
{

	 dice = new Dice();
}

 
public Dice getDice() 
{
	 return dice;
}
 
public Player winner()
{
	if( player1.getScore() > player2.getScore())
	{
		return player1;
	}
	else if(player2.getScore() > player1.getScore()) 
    
	{
		return player2;
	}	 
	return null;
}

public void play()
{
	 Player currentPlayer = player1;
	 int currentDice;
	 int playCounter = 2;
	 
	 for (int i = 0; i <= playCounter; i++)
	 {
		 
		 currentDice = dice.getDie1() + dice.getDie2();
		 
		 currentPlayer.updateScore(currentDice);
		 
		 if (currentPlayer == player1)
		 {
			 currentPlayer = player2;
		 }
		 else 
			 currentPlayer = player1;
		 if(winner() != null) 
		 {
	            System.out.println(winner() + " WINS !");
	        } 
		 else 
	        {
	            System.out.println("Game tie !");
	        }
	    }
 }


public void save()
{
	final String FILENAME = "DiceGame.txt"; 
	String message =  super.toString();  
	
try
 {

BufferedWriter file = new BufferedWriter(new FileWriter(FILENAME, true));
	
file.append(message + System.lineSeparator());
	
	file.close();
}
catch(IOException ioe)
{
	System.out.print("An I/O exception occurred:  ");
System.out.println(ioe.getMessage());

} 

}

public void Inputfile(String filename) 
{
	
	
	try
	{
		BufferedReader file = new BufferedReader(new FileReader(filename));
		
		String line = file.readLine();
		 
		while (line != null)
		{
			System.out.println(line);
			line = file.readLine();
		}
		
		file.close();
	}
	catch (FileNotFoundException fnfe)
	{
		System.out.println("ERROR:  File not found.");
	}
	catch (IOException ioe)
	{
		System.out.println("ERROR:  An I/O exception occurred.");
		System.out.println(ioe.getMessage());
	} 
	
}

	
}


