
public class Player
	{
		private int score;
		private String pName1;
		
	
		
		public Player()
		{
		 
		}


		public void setpName1(String pName1) 
		{
			this.pName1 = pName1;
		}
		


		public int getScore() 
		{
			return score;
		}


		public void setScore(int score)
		{
			this.score = score;
		}
		 
		public int updateScore(int currentDice) 
		{
		        score += currentDice;
		        return score;
		        
	    }

		@Override
		public String toString() 
		{
		
			return "Score = " + score + " " + pName1 ;
		}


	}
