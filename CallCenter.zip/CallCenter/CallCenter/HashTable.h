#pragma once
#include "Call.h"
#include <iostream>

class HashTable
{
private:
	static const int CAPACITY = 20;
	Call* calls[CAPACITY];
	int count;

public:
	HashTable()
	{
		count = 0;
		for (int i = 0; i < CAPACITY; i++)
			calls[i] = nullptr;
	}

	int hash(string id)
	{
		int sum = 0;

		for(int i =0; i<id.length(); i++ )
		{
			sum += id[i] % 10;

		}
		

		return sum % CAPACITY;
	}

	void add(Call* call)
	{
		int hashCode = hash(call->id);

		if (calls[hashCode] != nullptr)
		{
			

			// Resolve the collision with linear probe
			while (calls[hashCode] != nullptr)
				hashCode = (hashCode + 1) % CAPACITY;
		}
		calls[hashCode] = call;
	}

	Call* find(string ID)
	{
		
		int hashCode = hash(ID);

		// Linear probe for the ID
		while (calls[hashCode] != nullptr &&
			calls[hashCode]->id != ID)
			hashCode = (hashCode + 1) % CAPACITY;

		return calls[hashCode];
	}

	void display()
	{
		for (int i = 0; i < CAPACITY; i++)
		{
			std::cout << i << ")  ";
			if (calls[i] != nullptr)
			{
				std::cout << calls[i]->id << " "
					<< calls[i]->phoneNumber << " "
					<< calls[i]->time;
			}
			std::cout << std::endl;
		}
	}

	~HashTable()
	{
		for (int i = 0; i < CAPACITY; i++)
			if (calls[i] != nullptr)
				delete calls[i];
	}
};
