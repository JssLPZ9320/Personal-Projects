#pragma once
#include "Call.h"

class Queue
{
public:
	virtual void enqueue(Call value) = 0;
	virtual void dequeue() = 0;
	virtual Call getFront() = 0;
	virtual bool isEmpty() = 0;
};