#pragma once
#include "Call.h"

class Node
{
public:
	Call data;
	Node* next;

	Node()
	{
		next = nullptr;
	}

	Node(Call value)
	{
		data = value;
		next = nullptr;
	}

	~Node()
	{
		if (next != nullptr)
			delete next;
	}
};