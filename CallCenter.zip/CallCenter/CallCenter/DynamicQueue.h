#pragma once
#include "Queue.h"
#include"Call.h"
#include "LinkedList.h"

class DynamicQueue : public Queue
{
private:
	LinkedList data;

public:
	void enqueue(Call value)
	{
		data.addBack(value);
	}

	void dequeue()
	{
		data.removeFront();
	}

	Call getFront()
	{
		return data.getFront();
	}

	bool isEmpty()
	{
		return data.isEmpty();
	}
};