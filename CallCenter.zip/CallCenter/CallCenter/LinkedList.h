#pragma once
#include "Node.h"
#include <iostream>

class LinkedList
{
private:
	Node* first;

public:
	LinkedList()
	{
		first = new Node();
	}

	~LinkedList()
	{
		delete first;
	}

	Call getFront()
	{
		if (!isEmpty())
			return first->next->data;

		Call call;

		return call;
	}

	void addFront(Call value)
	{
		Node* newNode = new Node(value);
		newNode->next = first->next;
		first->next = newNode;
	}

	void addBack(Call value)
	{
		// find the end of the list
		Node* t = first;

		while (t->next != nullptr)
			t = t->next;

		t->next = new Node(value);
	}

	void removeFront()
	{
		Node* temp = first->next;
		first->next = temp->next;
		temp->next = nullptr;
		delete temp;
	}

	void removeBack()
	{
		Node* trailer = first;
		Node* temp = first->next;

		while (temp->next != nullptr)
		{
			trailer = trailer->next;
			temp = temp->next;
		}

		trailer->next = nullptr;
		delete temp;
	}

	Node* search(string value)
	{
		Node* t = first->next;

		while (t != nullptr)
		{
			if (t->data.id == value)
				return t;

			t = t->next;
		}

		return nullptr;
	}

	void removeValue(string value)
	{
		Node* trailer = first;
		Node* temp = first->next;

		while (temp != nullptr && temp->data.id != value)
		{
			temp = temp->next;
			trailer = trailer->next;
		}

		if (temp != nullptr)
		{
			trailer->next = temp->next;
			temp->next = nullptr;
			delete temp;
		}
	}



	bool isEmpty()
	{
		return first->next == nullptr;
	}

	void display()
	{
		Node* t = first->next;
		while (t != nullptr)
		{
			 t->data.display();
			t = t->next;
		}
		std::cout << std::endl;
	} 
};