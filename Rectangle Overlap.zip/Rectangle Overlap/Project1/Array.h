#pragma once
#include "Rectangle.h"

class Array
{
protected:
	int count;
	int capacity;

public:
	int getCount() { return count; };
	int getCapacity() { return capacity; };
	virtual void append(Rectangle* e) = 0;
	virtual Rectangle* get(int index) = 0;
};