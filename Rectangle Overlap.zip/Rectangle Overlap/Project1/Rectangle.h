#pragma once


class Rectangle
{
private:
	double x;
	double y;
	int width;
	int height;

public:
	Rectangle(double xVal, double yVal, int w, int h)
	{
		x = xVal;
		y = yVal;
		width = w;
		height = h;
	}



	double getX() { return x; }
	double getY() { return y; }
	int getWidth() { return width; }
	int getHeight() { return height; }
	
	bool intersect(Rectangle other)
	{
		double myLeft = x;
		double myTop = y;
		int myRight = x + width;
		int myBottom = y + height;

		double yourLeft = other.getX();
		double yourTop = other.getY();
		int yourRight = other.getX() + other.getWidth();
		int yourBottom = other.getY() + other.getHeight();

		// my top-left
		if (myLeft >= yourLeft && myLeft <= yourRight &&
			myTop >= yourTop && myTop <= yourBottom)
			return true;

		// my top-right
		if (myRight >= yourLeft && myRight <= yourRight &&
			myTop >= yourTop && myTop <= yourBottom)
			return true;

		// my bottom-left
		if (myLeft >= yourLeft && myLeft <= yourRight &&
			myBottom >= yourTop && myBottom <= yourBottom)
			return true;

		// my bottom-right
		if (myRight >= yourLeft && myRight <= yourRight &&
			myBottom >= yourTop && myBottom <= yourBottom)
			return true;

		// your top-left
		if (yourLeft >= myLeft && yourLeft <= myRight &&
			yourTop >= myTop && yourTop <= myBottom)
			return true;

		// your top-right
		if (yourRight >= myLeft && yourRight <= myRight &&
			yourTop >= myTop && yourTop <= myBottom)
			return true;

		// your bottom-left
		if (yourLeft >= myLeft && yourLeft <= myRight &&
			yourBottom >= myTop && yourBottom <= myBottom)
			return true;

		// your bottom-right
		if (yourRight >= myLeft && yourRight <= myRight &&
			yourBottom >= myTop && yourBottom <= myBottom)
			return true;

		return false;
	}

	
};