#include <iostream>
#include "Rectangle.h"
using namespace std;



int main()
{
	Rectangle r1(50, 50, 50, 50);
	Rectangle r2(20, 70, 50, 50);
	Rectangle r3(100, 10, 10, 20);

	if (r1.intersect(r2))
		cout << "Yep, collision between 1 and 2." << endl;
	else
		cout << "Nope, no overlap between 1 and 2." << endl;

	if (r1.intersect(r3))
		cout << "Yep, collision between 1 and 3." << endl;
	else
		cout << "Nope, no overlap between 1 and 3." << endl;

	if (r2.intersect(r1))
		cout << "Yep, collision between 2 and 1." << endl;
	else
		cout << "Nope, no overlap between 2 and 1." << endl;

	if (r2.intersect(r3))
		cout << "Yep, collision between 2 and 3." << endl;
	else
		cout << "Nope, no overlap between 2 and 3." << endl;



}