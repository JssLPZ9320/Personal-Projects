#pragma once
#include <iostream>
#include "Array.h"

class DynamicArray : public Array
{
private:
	static const int SIZE = 10;
	Rectangle** data;

public:
	DynamicArray()
	{
		count = 0;
		capacity = SIZE;
		data = new Rectangle * [capacity];
	}

	void append(Rectangle* item)
	{
		if (count < capacity)
		{
			data[count] = item;
			count++;
		}
		else
		{
			// double the capacity
			capacity *= 2;

			// create a new array with new capacity
			Rectangle** newArray = new Rectangle * [capacity];

			// copy old array into new arrray
			for (int i = 0; i < count; i++)
				newArray[i] = data[i];

			// append the new data
			newArray[count] = item;
			count++;

			// delete old array
			delete[] data;

			// replace old array with new one
			data = newArray;
		}
	}

	Rectangle* get(int index)
	{
		if (index >= 0 && index < count)
			return data[index];
		else
		{
			std::cout << "\tERROR:  Index out of range." << std::endl;
			return nullptr;
		}
	}

	~DynamicArray()
	{
		for (int i = 0; i < count; i++)
			delete data[i];

		delete[] data;
	}
};